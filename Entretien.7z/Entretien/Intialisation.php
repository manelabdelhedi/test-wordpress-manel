<?php

class Intialisation
{
    public function __construct()
    {

    }

  
     
public static function install()
{
global $wpdb;
$wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}post (id_attribut INT PRIMARY KEY,titre VARCHAR(255) NOT NULL, texte VARCHAR(500) NOT NULL);");


}

 public static function uninstall()
{
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}post;");
}
       
}