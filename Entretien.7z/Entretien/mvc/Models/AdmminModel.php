<?php
require_once('wp-includes/pluggable.php' );

class AdminModel{

public static function add($titre,$texte)
{

$email = get_bloginfo('admin_email');
$message = "Titre: ".$titre." </br> Texte: ".$texte;

//php mailer variables
$to = get_option('admin_email');
$subject = "Nouvel article";
$headers = 'From: '. $email . "\r\n" .
'Reply-To: ' . $email . "\r\n";
  global $wpdb;
  $table_name = $wpdb->prefix . "post";
  $existing = $wpdb->get_var("SELECT titre from $table_name WHERE titre = '".$titre."';");
  if (!$existing) {
      $wpdb->insert( $table_name, array( 'titre' => $titre, 'texte' => $texte ) );
      //add_action( 'plugins_loaded', 'renderHTML' );
$sent = wp_mail($to, $subject, strip_tags($message), $headers);
    if($sent) {
echo 'votre formulaire à été envoyée avec succès ';
    }//message sent!

  } else{
    echo 'cet article existe déjà';
  }


}

}