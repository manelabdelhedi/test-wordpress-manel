<?php
if (isset($_POST['titre'])){
AdminModel::add($_POST['titre'],$_POST['texte']); 
 }

 ?>