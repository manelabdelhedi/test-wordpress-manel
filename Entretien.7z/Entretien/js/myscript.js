<script>
$(function(){
  $('#sendform').submit(function(e){
titre= $(this).find("input[name=titre]").val();
texte= $(this).find("input[name=texte]").val();
var post_url = '<?php echo plugins_url("../Controller/AdinController.php", __FILE__); ?>';
$.ajax({
    type : "POST",
    url: post_url,
    data: $(this).serialize(),
    success : function(data) {
    $("#sendform").html("<p>Formulaire bien envoyé</p>");
    },
    error: function() {
        $("#sendform").html("<p>Erreur d'appel, le formulaire ne peut pas fonctionner</p>");
    }
});
      return false;
	  });
    });
</script>