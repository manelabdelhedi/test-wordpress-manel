<?php
/**
 * Plugin Name: entretien
 * Plugin URI: http://www.mywebsite.com/my-first-plugin
 * Description: Création de posts sur FE 
 * Version: 1.0
 * Author: Manel Abdelhedi
 */

class Entretien{

  public function __construct()
  {
    function fonction_shortcode_formulaire() {

      $form='<form id="sendform" method="POST" action="">
      <div class="form-group row">
      <label for="titre" class="col-sm-2 col-form-label">Titre</label>
      <div class="col-sm-10">
      <input type="text"  class="form-control" id="titre" name="titre" placeholder"votre titre">
      </div>
      </div>
      <div class="form-group row">
      <label for="texte" class="col-sm-2 col-form-label">Texte</label>
      <div class="col-sm-10">
      <input type="textarea" class="form-control" id="text" name="texte" placeholder="votre texte">
      </div>
      </div>
      <input type="submit" name="envoyer" id="envoyer" value="Envoyer"/>
      </form>';
      return $form;
    }


  add_shortcode('add_form', 'fonction_shortcode_formulaire'); 

    wp_enqueue_style('cssbootstrap','https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css');
   
    include_once plugin_dir_path( __FILE__ ).'/intialisation.php';
    include_once plugin_dir_path( __FILE__ ).'mvc/Models/AdmminModel.php';
    include_once plugin_dir_path( __FILE__ ).'mvc/Controller/AdminController.php';
  

      new Intialisation();

    register_activation_hook(__FILE__, array('intialisation', 'install'));
    register_deactivation_hook(__FILE__, array('intialisation', 'uninstall'));
  }




}
new Entretien();